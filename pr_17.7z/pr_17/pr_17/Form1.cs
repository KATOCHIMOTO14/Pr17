﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_17
{
    public partial class Form1 : Form

    {
        private List<Person> people = new List<Person>();
        public Form1()
        {
            InitializeComponent();
        }


        /// <summary>
        /// обновление списка
        /// </summary>
        private void UpdateListView()
        {
            personsListView.Items.Clear();
            foreach (Person person in people)
            {
                ListViewItem newItem = personsListView.Items.Add(person.FirstName);
                newItem.SubItems.Add(person.LastName);
                newItem.SubItems.Add(person.Age.ToString());
            }
        }
        
        private void addPersonButton_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            if (f2.ShowDialog() != DialogResult.OK) 
                return;
            people.Add(Form2._person);
            UpdateListView();
        }

        private void editPersonButton_Click(object sender, EventArgs e)
        {
            if (personsListView.SelectedItems.Count == 0)
                return;
            ListViewItem itemc= personsListView.SelectedItems[0];
            var selectedPerson = people[personsListView.SelectedIndices[0]];
            Form2 editForm = new Form2(selectedPerson);

            if (editForm.ShowDialog() == DialogResult.OK)
            {
                UpdateListView();
            }
            else 
            {
                MessageBox.Show("Пожайлуста, выберите человека для редактирования");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            
        }
    }
}
