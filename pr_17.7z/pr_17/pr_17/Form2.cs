﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_17
{
    public partial class Form2 : Form
    {
        public static Person _person;
        public Form2()
        {
            InitializeComponent();
            _person = new Person();
        }
        public Form2(Person person)
        {
            InitializeComponent();
            _person = new Person();
            _person = person;
            firstNameTextBox.Text = _person.FirstName;
            lastNameTextBox.Text = _person.LastName;
            ageNumericUpDown.Value = _person.Age;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            _person.FirstName = firstNameTextBox.Text;
            _person.LastName = lastNameTextBox.Text;
            _person.Age = (int)ageNumericUpDown.Value;

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
